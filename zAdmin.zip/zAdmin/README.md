# zAdmin

### Buy new zAdmin Ultimate:
https://pablo.five-shop.fr/package/4819036

## USE F10 TO OPEN THE MENU

### Looking for the ESX version ?
https://github.com/PABLO-1610/zAdmin/tree/esx

Admin menu
• OneSync Infinity friendly !
• Easy to use
• Free <3

Support Discord: https://discord.gg/6ATKeR2jSM
